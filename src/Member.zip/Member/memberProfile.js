import React from 'react'
import './memberProfile.css'
function memberProfile() {
  return (
    <div>
      <h1>Member profile</h1>
    </div>
  )
}

export default memberProfile
